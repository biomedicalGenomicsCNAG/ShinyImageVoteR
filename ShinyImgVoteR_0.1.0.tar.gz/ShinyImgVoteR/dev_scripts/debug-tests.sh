#!/usr/bin/env bash
set -euo pipefail

# Get project root (you can hardcode if needed)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_ROOT"

echo "Running testthat tests in interactive debug mode..."
echo "working directory: $(pwd)"

exec R --vanilla --quiet --interactive -f dev_scripts/debug-tests.R
# got to the root of the package
devtools::load_all(".")
ShinyImgVoteR::run_voting_app()
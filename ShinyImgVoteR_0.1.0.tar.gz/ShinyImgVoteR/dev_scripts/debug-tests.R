#!/usr/bin/env Rscript

# Use r_session (interactive R subprocess)
sess <- callr::r_session$new()

sess$run(function() {
  options(error = recover)

  if (requireNamespace("devtools", quietly = TRUE)) {
    devtools::load_all()
  } else {
    pkgload::load_all()
  }

  testthat::test_dir("tests/testthat", reporter = testthat::DebugReporter$new())
})

sess$close()

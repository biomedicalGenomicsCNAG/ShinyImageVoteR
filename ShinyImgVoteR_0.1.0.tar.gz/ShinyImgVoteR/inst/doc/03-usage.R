## ----setup, include=FALSE-----------------------------------------------------
# load your package and shiny
library(ShinyImgVoteR)
library(shiny)

Sys.setenv("IMGVOTER_BASE_DIR" = getwd())
config_file_path <- file.path(get_app_dir(), "default_env", "config", "config.yaml")
cfg <- load_config(config_file_path)

init_environment(config_file_path)

shiny::addResourcePath(
  prefix = "images",
  directoryPath = cfg$images_dir
)

shiny::addResourcePath(
  "www",
  system.file("shiny-app", "www", package = "ShinyImgVoteR")
)

message("CONFIG YAML:\t", normalizePath(config_file_path))
message("IMAGES DIR:\t", normalizePath(cfg$images_dir))
message("SQLITE DB:\t", normalizePath(cfg$sqlite_file))

## ----ui, echo=FALSE-----------------------------------------------------------
# shiny::fluidPage(
#   shiny::tags$h3("Current Working Directory"),
#   shiny::verbatimTextOutput("cwd")
# )

## ----ui2, echo=FALSE, include=TRUE--------------------------------------------
Sys.setenv("IMGVOTER_CONFIG_FILE" = config_file_path)
votingAppUI(cfg)

## ----server, context="server", include=FALSE----------------------------------
# output$cwd <- renderText({
#   getwd()
# })
con <- DBI::dbConnect(RSQLite::SQLite(), dbname = cfg$sqlite_file)
on.exit(DBI::dbDisconnect(con), add = TRUE)
makeVotingAppServer(con)

## ----ui3, echo=FALSE, include=TRUE--------------------------------------------
Sys.setenv("IMGVOTER_CONFIG_FILE" = config_file_path)
votingAppUI(cfg)


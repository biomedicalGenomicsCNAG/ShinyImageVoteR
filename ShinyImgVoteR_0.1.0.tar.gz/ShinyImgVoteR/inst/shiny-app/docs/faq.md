# FAQ
## What is this application about?
This application allows users to vote on genomic mutations based on their annotations.

## How do I log in?
You will receive a personal link to retrieve your password. Click the link to set your password and then use it together with your user name to log in.

## Where can I report bugs/issues?
You can report bugs/issues on our GitHub repository's issue tracker.
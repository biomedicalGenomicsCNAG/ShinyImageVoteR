// Mock hotkeys.js for testing
console.log('Hotkeys loaded');

# Frequently Asked Questions

This is a mock FAQ file for testing purposes.

## Question 1
Answer 1

## Question 2
Answer 2

# This file is part of the standard testthat structure
# It configures testthat for this package

library(testthat)
library(ShinyImgVoteR)

test_check("ShinyImgVoteR")

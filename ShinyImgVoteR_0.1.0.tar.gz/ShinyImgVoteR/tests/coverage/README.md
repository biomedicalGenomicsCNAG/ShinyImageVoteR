Test coverage is generated using [covr](https://covr.r-lib.org/).
The coverage report can be viewed in a web browser.
This directory contains a symlink to the screenshots directory in /vol
Thus, the images are available at:
https://simplevm-proxy-prod.denbi.dkfz.de/automaticlobster_100/b1mg-variant-voter-v2/images/

Example image url
https://simplevm-proxy-prod.denbi.dkfz.de/automaticlobster_100/b1mg-variant-voter-v2/images/screenshot_URO_003_mutations_varSorted_redoBAQ/0a0b53acbf9fac0f45dfcf77a8c6baae.png
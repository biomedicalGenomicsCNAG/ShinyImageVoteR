Add an empty file called "STOP" in this directory to tell the server to stop the shiny app

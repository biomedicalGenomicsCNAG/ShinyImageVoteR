# User Data Directory Content

Institute:
 - User1:
    - user_info.json
    - user_annotations.tsv
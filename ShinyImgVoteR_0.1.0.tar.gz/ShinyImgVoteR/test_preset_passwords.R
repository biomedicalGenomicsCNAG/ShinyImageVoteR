#!/usr/bin/env Rscript

# Quick test script to verify preset password functionality
library(yaml)

# Test YAML parsing
test_yaml <- "
training_answers_not_saved:
  - test: 1234
  - test2: abcd
cnag:
  - ileist
  - igut: mypassword
  - gaguileta
"

# Write test file
temp_dir <- tempdir()
yaml_file <- file.path(temp_dir, "test_institute2userids2password.yaml")
writeLines(test_yaml, yaml_file)

# Read and parse
institute_data <- yaml::read_yaml(yaml_file)

cat("Raw YAML data structure:\n")
str(institute_data)

# Test parsing logic
user_institute_map <- data.frame(
  userid = character(0), 
  institute = character(0), 
  preset_password = character(0),
  stringsAsFactors = FALSE
)

for (institute in names(institute_data)) {
  users <- institute_data[[institute]]
  
  cat("\nInstitute:", institute, "\n")
  cat("Users structure:\n")
  str(users)
  
  # Process each user entry
  for (user_entry in users) {
    cat("Processing user_entry:", "\n")
    str(user_entry)
    
    if (is.list(user_entry) && length(user_entry) == 1) {
      # Format: - username: password
      username <- names(user_entry)[1]
      preset_password <- as.character(user_entry[[1]])
      cat("  Found preset password:", username, "->", preset_password, "\n")
    } else if (is.character(user_entry)) {
      # Format: - username (no preset password)
      username <- trimws(gsub("^-", "", user_entry))
      preset_password <- NA_character_
      cat("  Found simple username:", username, "\n")
    } else {
      # Convert to character and treat as simple username
      username <- trimws(gsub("^-", "", as.character(user_entry)))
      preset_password <- NA_character_
      cat("  Found converted username:", username, "\n")
    }
    
    # Add to the mapping
    institute_user <- data.frame(
      userid = username,
      institute = institute,
      preset_password = preset_password,
      stringsAsFactors = FALSE
    )
    user_institute_map <- rbind(user_institute_map, institute_user)
  }
}

cat("\nFinal user mapping:\n")
print(user_institute_map)

# Clean up
unlink(yaml_file)

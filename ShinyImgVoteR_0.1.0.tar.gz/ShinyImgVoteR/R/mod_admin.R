#' Admin module UI
#'
#' Displays password retrieval tokens for users and allows admins to add new users,
#' download user annotations, and reset user annotations.
#'
#' @param id Module namespace
#' @param cfg App configuration object
#'
#' @return A Shiny UI element
#' @export
adminUI <- function(id, cfg) {
  ns <- shiny::NS(id)
  shiny::fluidPage(
    theme = cfg$theme,
    shinyjs::useShinyjs(),
    shiny::div(
      class = "d-flex gap-2 mb-3",
      shiny::actionButton(ns("refresh_tokens"), "Refresh"),
      shiny::actionButton(ns("download_annotations_btn"), "Download annotations"),
      shiny::downloadButton(
        ns("download_annotations"),
        label = "",
        style = "display: none;"
      )
    ),
    DT::dataTableOutput(ns("users_table"))
  )
}

#' Admin module server
#'
#' Shows password retrieval tokens for users, allows admins to add new users,
#' enables downloading user annotations, and provides functionality to reset user annotations.
#'
#' @param id Module namespace
#' @param cfg App configuration
#' @param login_trigger Reactive containing login data
#' @param db_pool Database connection pool
#' @param tab_trigger Optional reactive triggered when admin tab is selected
#' @export
adminServer <- function(id, cfg, login_trigger, db_pool, tab_trigger = NULL) {
  shiny::moduleServer(id, function(input, output, session) {
    # Reactive trigger for table refresh
    table_refresh_trigger <- shiny::reactiveVal(0)

    tab_change_trigger <- shiny::reactive({
      if (!is.null(tab_trigger)) {
        tab_trigger()
      } else {
        NULL
      }
    })

    users_tbl <- shiny::eventReactive(
      c(
        login_trigger(),
        input$refresh_tokens,
        tab_change_trigger(),
        table_refresh_trigger()
      ),
      {
        shiny::req(login_trigger()$admin == 1)
        DBI::dbGetQuery(
          db_pool,
          paste(
            "SELECT userid, institute, pwd_retrieval_token FROM passwords",
            "WHERE pwd_retrieval_token IS NOT NULL"
          )
        )
      }
    )

    output$users_table <- DT::renderDT({
      tbl <- users_tbl()
      base_url <- build_base_url(session)
      # --- rows
      tbl$link <- paste0(
        base_url,
        "?pwd_retrieval_token=",
        tbl$pwd_retrieval_token
      )
      tbl$action_btns <- sprintf(
        '<div class="d-flex gap-1">
          <button
              class="btn btn-primary btn-sm"
              title="View email template"
              onclick="Shiny.setInputValue(
                \'%s\', \'%s\',
                {priority: \'event\'});"
          >
            Email Template
          </button>
          <button
              class="btn btn-warning btn-sm"
              title="Reset user annotations"
              onclick="Shiny.setInputValue(
                \'%s\', 
                {userid: \'%s\', institute: \'%s\', nonce: Math.random()},
                {priority: \'event\'});"
          >
            Reset Annotations
          </button>
        </div>',
        session$ns("email_template_btn"),
        tbl$userid,
        session$ns("reset_annotations_btn"),
        tbl$userid,
        tbl$institute
      )
      # Remove the password retrieval token column
      tbl$pwd_retrieval_token <- NULL
      cols <- c("User ID", "Institute", "Password Retrieval Link", "Action")
      names(tbl) <- cols

      # Ensure character cols & base df
      tbl[] <- lapply(tbl, as.character)
      tbl <- as.data.frame(tbl, stringsAsFactors = FALSE, check.names = FALSE)

      # --- Dummy new row (names & order must match `cols`)
      ns <- session$ns

      add_new_user_btn_html <- sprintf(
        '<button
            class="btn btn-success btn-sm"
            title="Add user"
            onclick="(function(){
              var u = document.getElementById(\'%s\').value.trim();
              var i = document.getElementById(\'%s\').value.trim();
              // nonce ensures the event fires even with same values
              Shiny.setInputValue(
                \'%s\',
                {userid: u, institute: i, nonce: Math.random()},
                {priority:\'event\'}
              );
            })()"
        >
          &#x2795; new user
        </button>',
        ns("new_userid"),
        ns("new_institute"),
        ns("add_user_btn")
      )

      new_row <- data.frame(
        `User ID` = as.character(shiny::textInput(
          ns("new_userid"),
          NULL,
          width = "100%"
        )),
        Institute = as.character(shiny::textInput(
          ns("new_institute"),
          NULL,
          width = "100%"
        )),
        `Password Retrieval Link` = "",
        Action = add_new_user_btn_html,
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
      new_row <- new_row[, cols, drop = FALSE] # enforce same order

      # Prefer bind_rows for robustness; could also do: rbind(new_row[cols], tbl)
      show_df <- dplyr::bind_rows(new_row, tbl)

      DT::datatable(
        show_df,
        escape = FALSE,
        rownames = FALSE,
        extensions = c("Buttons"),
        selection = list(mode = "single", target = "row"),
        options = list(
          pageLength = 10,
          dom = "Blfrtip", # enables buttons
          buttons = list(
            "selectAll",
            "selectNone"
          )
        )
      )
    })

    # Track selected user
    selected_user <- shiny::reactive({
      sel <- input$users_table_rows_selected
      tbl <- users_tbl()

      if (length(sel) == 0 || is.null(tbl) || nrow(tbl) == 0) {
        return(NULL)
      }

      idx <- sel[1] - 1

      if (idx < 1 || idx > nrow(tbl)) {
        return(NULL)
      }

      list(
        userid = tbl$userid[idx],
        institute = tbl$institute[idx]
      )
    })

    shiny::observe({
      shinyjs::toggleState("download_annotations_btn", condition = !is.null(selected_user()))
    })

    selected_annotation_path <- shiny::reactiveVal(NULL)

    find_annotation_file <- function(user_info) {
      if (is.null(user_info)) {
        return(NULL)
      }

      user_dir <- file.path(cfg$user_data_dir, user_info$institute, user_info$userid)

      if (!dir.exists(user_dir)) {
        return(NULL)
      }

      preferred <- file.path(user_dir, paste0(user_info$userid, "_annotations.tsv"))

      if (file.exists(preferred)) {
        print(paste("Found preferred annotation file:", preferred))
        return(preferred)
      }

      files <- list.files(user_dir, pattern = "_annotations\\.tsv$", full.names = TRUE)

      if (length(files) == 0) {
        return(NULL)
      }

      print("Annotations files found:")
      print(files)

      files[[1]]
    }

    output$download_annotations <- shiny::downloadHandler(
      filename = function() {
        path <- selected_annotation_path()

        shiny::req(path)
        shiny::req(file.exists(path))

        basename(path)
      },
      content = function(file) {
        path <- selected_annotation_path()

        shiny::req(path)
        shiny::req(file.exists(path))

        # normalize for weird relative paths / symlinks
        src <- normalizePath(path, mustWork = TRUE)
        dst <- normalizePath(file, mustWork = FALSE)

        tryCatch(
          {
            ok <- file.copy(src, dst, overwrite = TRUE)
            if (!ok) stop("file.copy returned FALSE (likely permissions or path problem)")
          },
          error = function(e) {
            shiny::showNotification(
              paste("Download failed:", conditionMessage(e)),
              type = "error", duration = 7
            )
            stop(e) # rethrow so the browser gets a proper download error
          }
        )
      },
      contentType = "text/tab-separated-values; charset=utf-8"
    )

    shiny::outputOptions(
      output,
      "download_annotations",
      suspendWhenHidden = FALSE
    )

    shiny::observeEvent(selected_user(),
      {
        info <- selected_user()

        if (is.null(info)) {
          selected_annotation_path(NULL)
        }
      },
      ignoreNULL = FALSE
    )

    # Handle email template button clicks
    shiny::observeEvent(input$email_template_btn, {
      user_id <- input$email_template_btn
      tbl <- users_tbl()
      user_row <- tbl[tbl$userid == user_id, ]

      if (nrow(user_row) > 0) {
        # Get base URL using helper function
        base_url <- build_base_url(session)

        retrieval_link <- paste0(
          base_url,
          "?pwd_retrieval_token=",
          user_row$pwd_retrieval_token
        )

        email_template <- paste0(
          "Subject: Password for the B1MG Variant Voting beta\n\n",
          "Dear ",
          user_id,
          ",\n\n",
          "Your account has been created in order to retrieve the password please click on the following link:\n\n",
          retrieval_link,
          "\n\n",
          "Note, this link will work only once. So store the displayed password immediately!\n\n",
          "If you have any questions, please contact help.b1mg@cnag.eu\n\n",
          "Kind regards,\n",
          "The B1MG Variant Voting Admin Team at CNAG"
        )

        shiny::showModal(shiny::modalDialog(
          title = paste("Email Template for", user_id),
          shiny::tags$pre(
            style = "white-space: pre-wrap; font-family: monospace;",
            email_template
          ),
          easyClose = TRUE,
          footer = shiny::modalButton("Close")
        ))
      }
    })

    shiny::observeEvent(input$download_annotations_btn, {
      print("Download annotations button clicked")
      info <- selected_user()
      print("Selected user info:")
      print(info)

      annotation_path <- find_annotation_file(info)
      print("Found annotation path:")
      print(annotation_path)

      if (is.null(annotation_path)) {
        print("No annotation file found, showing modal.")
        shiny::showModal(shiny::modalDialog(
          title = "Annotations not found",
          paste0(
            "No annotations file was found for ",
            info$userid,
            " at institute ",
            info$institute,
            "."
          ),
          easyClose = TRUE,
          footer = shiny::modalButton("Close")
        ))
        return()
      }

      print("Setting selected annotation path")
      selected_annotation_path(annotation_path)

      print("Triggering download...")
      print("session$ns('download_annotations'):")
      print(session$ns("download_annotations"))
      shinyjs::runjs(sprintf(
        "document.getElementById('%s').click();",
        session$ns("download_annotations")
      ))
    })

    shiny::observeEvent(input$add_user_btn, {
      print("Add user button clicked")

      shiny::req(login_trigger()$admin == 1)
      user_id <- trimws(input$add_user_btn$userid)
      institute <- trimws(input$add_user_btn$institute %||% "")

      if (user_id == "" || institute == "") {
        shiny::showModal(shiny::modalDialog(
          title = "Missing information",
          "Please provide both user ID and institute.",
          easyClose = TRUE,
          footer = shiny::modalButton("Close")
        ))
        return()
      }

      existing <- DBI::dbGetQuery(
        db_pool,
        "SELECT userid FROM passwords WHERE userid = ?",
        params = list(user_id)
      )

      if (nrow(existing) > 0) {
        shiny::showModal(shiny::modalDialog(
          title = "User exists",
          "A user with this ID already exists.",
          easyClose = TRUE,
          footer = shiny::modalButton("Close")
        ))
        return()
      }

      password <- generate_password()
      token <- digest::digest(paste0(user_id, Sys.time(), runif(1)))

      DBI::dbExecute(
        db_pool,
        "INSERT INTO passwords (userid, institute, password, admin, pwd_retrieval_token, pwd_retrieved_timestamp) VALUES (?, ?, ?, 0, ?, NULL)",
        params = list(user_id, institute, password, token)
      )

      # Create user directory structure
      tryCatch(
        {
          create_user_directory(cfg$user_data_dir, institute, user_id)
          message(paste("Created directory for user:", user_id, "at institute:", institute))
        },
        error = function(e) {
          warning(paste("Failed to create directory for user:", user_id, "-", e$message))
        }
      )

      base_url <- build_base_url(session)
      retrieval_link <- paste0(base_url, "?pwd_retrieval_token=", token)

      shiny::showModal(shiny::modalDialog(
        title = paste("User", user_id, "added"),
        shiny::tags$pre(
          style = "white-space: pre-wrap; font-family: monospace;",
          "User successfully added and password generated."
        ),
        easyClose = TRUE,
        footer = shiny::modalButton("Close")
      ))

      # Clear fields and refresh table
      shinyjs::runjs(sprintf(
        "document.getElementById('%s').value=''; document.getElementById('%s').value='';",
        session$ns("new_userid"),
        session$ns("new_institute")
      ))

      # Trigger table refresh
      table_refresh_trigger(table_refresh_trigger() + 1)
    })

    # Handle reset annotations button clicks
    shiny::observeEvent(input$reset_annotations_btn, {
      print("Reset annotations button clicked")
      
      shiny::req(login_trigger()$admin == 1)
      user_id <- trimws(input$reset_annotations_btn$userid)
      institute <- trimws(input$reset_annotations_btn$institute %||% "")
      
      if (user_id == "" || institute == "") {
        shiny::showModal(shiny::modalDialog(
          title = "Missing information",
          "Unable to identify user. Please try again.",
          easyClose = TRUE,
          footer = shiny::modalButton("Close")
        ))
        return()
      }
      
      # Show confirmation dialog
      shiny::showModal(shiny::modalDialog(
        title = paste("Reset Annotations for", user_id),
        shiny::div(
          shiny::p(paste0(
            "Are you sure you want to reset all annotations for user '", user_id, 
            "' from institute '", institute, "'?"
          )),
          shiny::p("This will:"),
          shiny::tags$ul(
            shiny::tags$li("Keep the header row"),
            shiny::tags$li("Keep the first three columns (coordinates, REF, ALT)"),
            shiny::tags$li("Clear all other annotation data (votes, observations, comments, etc.)")
          ),
          shiny::p(style = "color: red; font-weight: bold;", 
                   "This action cannot be undone!")
        ),
        footer = shiny::div(
          shiny::modalButton("Cancel"),
          shiny::actionButton(
            session$ns("confirm_reset"),
            "Yes, Reset Annotations",
            class = "btn-danger",
            onclick = sprintf(
              "Shiny.setInputValue('%s', {userid: '%s', institute: '%s', nonce: Math.random()}, {priority: 'event'});",
              session$ns("confirm_reset_action"),
              user_id,
              institute
            )
          )
        ),
        easyClose = FALSE
      ))
    })
    
    # Handle confirmed reset action
    shiny::observeEvent(input$confirm_reset_action, {
      print("Confirmed reset action")
      
      shiny::req(login_trigger()$admin == 1)
      user_id <- trimws(input$confirm_reset_action$userid)
      institute <- trimws(input$confirm_reset_action$institute %||% "")
      
      if (user_id == "" || institute == "") {
        return()
      }
      
      # Find the annotation file
      user_info <- list(userid = user_id, institute = institute)
      annotation_path <- find_annotation_file(user_info)
      
      if (is.null(annotation_path)) {
        shiny::showModal(shiny::modalDialog(
          title = "Annotations not found",
          paste0(
            "No annotations file was found for ",
            user_id,
            " at institute ",
            institute,
            "."
          ),
          easyClose = TRUE,
          footer = shiny::modalButton("Close")
        ))
        return()
      }
      
      # Perform the reset
      success <- reset_user_annotations(
        annotation_path, 
        cfg$user_annotations_colnames,
        db_pool,
        cfg
      )
      
      if (success) {
        shiny::showModal(shiny::modalDialog(
          title = "Success",
          paste0(
            "Annotations for user '", user_id, 
            "' have been successfully reset."
          ),
          easyClose = TRUE,
          footer = shiny::modalButton("Close")
        ))
      } else {
        shiny::showModal(shiny::modalDialog(
          title = "Error",
          paste0(
            "Failed to reset annotations for user '", user_id, 
            "'. Please check the server logs for details."
          ),
          easyClose = TRUE,
          footer = shiny::modalButton("Close")
        ))
      }
    })
  })
}

# TODO
# Allow the upload of user data via CSV/TSV
# Columns: UserID/Institute/Password/Admin
# To enable bulk user creation

# TODO
# The addition of new users should update the
# institute2userids2password.yaml file accordingly.

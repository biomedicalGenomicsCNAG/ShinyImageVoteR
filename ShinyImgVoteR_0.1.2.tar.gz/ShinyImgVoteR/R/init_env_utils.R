#' Copy a directory from the app to a target path
#' This function copies a directory from the app's default environment to a specified target path.
#'
#' @keywords internal
#' @param target_dir_path Character. Path to the target directory where the app directory will be copied.
#'
#' @return Character path to the copied directory
copy_dir_from_app <- function(target_dir_path) {
  app_dir <- system.file("shiny-app", package = "ShinyImgVoteR")

  target_dir_name <- basename(target_dir_path)
  dir_to_copy <- file.path(app_dir, "default_env", target_dir_name)

  R.utils::copyDirectory(
    from = dir_to_copy,
    to = target_dir_path
  )

  message(glue::glue(
    "Copied {target_dir_name} directory from ShinyImgVoteR",
    " to {target_dir_path}"
  ))
  return(normalizePath(target_dir_path, mustWork = TRUE))
}

#' Create a Directory Safely
#'
#' Validates that the target directory name is a single “word” (letters, digits, and/or underscores only)
#' before attempting to create it. Optionally handles nested creation, warnings, and permission bits.
#'
#' @param path Character. The name (or path) of the directory to create.
#'        Only the final component (basename) is validated.
#' @param pattern Character. A regular expression that the directory name must match.
#'        Default is `"^[A-Za-z0-9_]+$"`, i.e. one or more letters, digits, or underscores.
#' @param showWarnings Logical. If `TRUE`, warns when the directory already exists or cannot be created.
#'        Default is `TRUE`.
#' @param recursive Logical. If `TRUE`, creates any missing parent directories (like `mkdir -p`). Default is `FALSE`.
#' @param mode Character or numeric. Directory permissions in octal (e.g. `"0777"`). Default is `"0777"`.
#'
#' @return Invisibly returns `TRUE` if the directory was successfully created, `FALSE` otherwise.
#'         If the directory already exists, returns `FALSE` (with a message, unless `showWarnings = FALSE`).
#'
#' @examples
#' # Successful creation
#' safe_dir_create("data_folder")
#'
#' # Fails validation (contains spaces)
#' try(safe_dir_create("my data"))
safe_dir_create <- function(
  path,
  pattern = "^[A-Za-z0-9_]+$",
  showWarnings = TRUE,
  recursive = FALSE
) {
  name <- basename(path)

  # Validate against the pattern
  if (!grepl(pattern, name)) {
    stop(
      "Invalid directory name: '",
      name,
      "'. Only letters, digits and underscores are allowed."
    )
  }

  # If it already exists, warn or message and return FALSE
  if (dir.exists(path)) {
    if (showWarnings) {
      message("Directory '", path, "' already exists.")
    }
    return(invisible(FALSE))
  }

  # Create the directory
  dir.create(
    path,
    showWarnings = showWarnings,
    recursive = recursive
  )
}

#' Create user directory structure
#'
#' Creates the directory structure for a user under their institute folder.
#' This ensures both the institute and user directories exist.
#'
#' @param user_data_dir Character. Base directory for user data
#' @param institute Character. Institute name
#' @param user_id Character. User ID
#'
#' @return Character. Path to the created user directory
#' @export
create_user_directory <- function(user_data_dir, institute, user_id) {
  # Validate institute and user_id
  pattern <- "^[A-Za-z0-9_]+$"
  
  if (!grepl(pattern, institute)) {
    stop(
      "Invalid institute name: '",
      institute,
      "'. Only letters, digits and underscores are allowed."
    )
  }
  
  if (!grepl(pattern, user_id)) {
    stop(
      "Invalid user ID: '",
      user_id,
      "'. Only letters, digits and underscores are allowed."
    )
  }
  
  # Create institute directory if it doesn't exist
  institute_dir <- file.path(user_data_dir, institute)
  if (!dir.exists(institute_dir)) {
    dir.create(institute_dir, recursive = TRUE, showWarnings = FALSE)
    message("Created institute directory: ", institute_dir)
  }
  
  # Create user directory
  user_dir <- file.path(institute_dir, user_id)
  if (!dir.exists(user_dir)) {
    dir.create(user_dir, recursive = FALSE, showWarnings = FALSE)
    message("Created user directory: ", user_dir)
  }
  
  return(user_dir)
}

# Ensure that .gitignore in dir contains the given patterns
#'
#' This function checks if a .gitignore file exists in the specified directory.
#' If it does not exist, it creates one. It then ensures that the specified patterns
#' are present in the .gitignore file, adding them if they are missing.
#'
#' @keywords internal
#' @param dir Character. Directory path where the .gitignore file should be checked/created.
#' @param patterns Character vector. Patterns to ensure in the .gitignore file.
#'
#' @return Character path to the .gitignore file
#'
ensure_gitignore <- function(directory, patterns) {
  dir_full_path <- normalizePath(directory, mustWork = TRUE)
  gi_path <- file.path(dir_full_path, ".gitignore")

  existing <- character(0)
  if (file.exists(gi_path)) {
    existing <- readLines(gi_path, warn = FALSE)
    message(glue::glue("Found existing .gitignore at {gi_path}"))
  }

  # Determine which patterns are missing
  missing <- setdiff(patterns, existing)
  message(glue::glue(
    "Checking .gitignore in {dir_full_path} for patterns: {paste(patterns, collapse=', ')}"
  ))
  message("missing patterns:")
  print(missing)
  if (length(missing) > 0) {
    new_contents <- c(existing, missing)
    writeLines(new_contents, gi_path)
    tryCatch(
      {
        message(glue::glue(
          "Added {length(missing)} pattern{?s} to .gitignore: {paste(missing, collapse=', ')}"
        ))
      },
      error = function(e) {
        # Handle the error—e$message contains the error text
        message("Failed to explain .gitignore updates: ", e$message)
        # You could also stop(), warning(), or take other recovery actions here
      }
    )
  } else {
    message("All specified patterns already present in .gitignore.")
  }

  invisible(gi_path)
}

#' Generate a random password
#'
#' Creates a random password of specified length using letters, numbers, and special characters.
#'
#' @param length Integer. Length of the password to generate. Defaults to 12.
#' @param pattern Character string. characters to include in the password.
#'
#' @return Character string containing the generated password
generate_password <- function(length = 12, pattern = "!@#$%^&*") {
  chars <- c(letters, LETTERS, as.character(0:9), strsplit(pattern, "")[[1]])
  paste(sample(chars, length, replace = TRUE), collapse = "")
}

#' Retrieve a password using a retrieval token
#'
#' Looks up the password corresponding to a retrieval link token and marks the
#' link as shown in the database.
#'
#' @param token Character. Retrieval token from the URL path.
#' @param conn Database connection object.
#' @return Character password if token is valid, otherwise NULL.
#' @keywords internal
retrieve_password_from_link <- function(token, conn) {
  print("In retrieve_password_from_link")
  print("token")
  print(token)
  res <- DBI::dbGetQuery(
    conn,
    "SELECT userid, password FROM passwords WHERE pwd_retrieval_token = ? AND pwd_retrieved_timestamp IS NULL",
    params = list(token)
  )
  if (nrow(res) == 0) {
    return("Invalid or already used password retrieval link.")
  }
  DBI::dbExecute(
    conn,
    "UPDATE passwords SET pwd_retrieved_timestamp = ? WHERE pwd_retrieval_token = ?",
    params = list(as.character(Sys.time()), token)
  )
  res$password[[1]]
}

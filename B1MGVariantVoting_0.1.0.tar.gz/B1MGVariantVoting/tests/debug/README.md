Various scripts to debug tests

# This file is part of the standard testthat structure
# It configures testthat for this package

library(testthat)
library(B1MGVariantVoting)

test_check("B1MGVariantVoting")

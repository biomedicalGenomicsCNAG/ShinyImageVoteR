library(shiny)
runApp(port = 8000, launch.browser = TRUE)

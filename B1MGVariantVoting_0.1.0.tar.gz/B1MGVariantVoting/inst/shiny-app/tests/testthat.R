library(testthat)
library(shiny)
library(DBI)
library(RSQLite)
library(pool)

# Set up test environment
test_check("variant_voting")

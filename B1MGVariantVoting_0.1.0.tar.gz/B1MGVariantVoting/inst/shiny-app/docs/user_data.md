1. layer institutes
2. layer users

Note: when a row in annotations.tsv has no value in the shiny session id column
and all the other values except of the coordinates are NA then this image has been skipped
for this user.ther values except of the coordinates are NA then this image has been skipped
for this user.

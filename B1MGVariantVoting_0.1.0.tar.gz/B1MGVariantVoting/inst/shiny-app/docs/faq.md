# FAQ
## What is this application about?
This application allows users to vote on genomic variants based on their annotations.

## How do I log in?
We (CNAG) will provide you with a username and password. Use these credentials to log in on the login page.

## Where can I report bugs/issues?
You can report bugs/issues on our GitHub repository's issue tracker.
#' Database Utility Functions
#'
#' Utility functions for database operations in the B1MG Variant Voting application.
#'
#' @name db_utils
NULL

#' Create a test database pool
#'
#' Creates a temporary SQLite database pool for testing purposes.
#'
#' @return List containing pool object and database file path
#' @export
create_test_db_pool <- function() {
  db_file <- tempfile(fileext = ".sqlite")
  pool <- pool::dbPool(RSQLite::SQLite(), dbname = db_file)
  
  # Create required tables
  DBI::dbExecute(pool, "
    CREATE TABLE annotations (
      coordinates TEXT,
      REF TEXT,
      ALT TEXT,
      variant TEXT,
      path TEXT,
      vote_count_correct INTEGER DEFAULT 0,
      vote_count_no_variant INTEGER DEFAULT 0,
      vote_count_different_variant INTEGER DEFAULT 0,
      vote_count_not_sure INTEGER DEFAULT 0,
      vote_count_total INTEGER DEFAULT 0
    )
  ")
  
  DBI::dbExecute(pool, "
    CREATE TABLE sessionids (
      user TEXT,
      sessionid TEXT,
      login_time TEXT,
      logout_time TEXT
    )
  ")
  
  # Insert some test data
  DBI::dbExecute(pool, "
    INSERT INTO annotations (coordinates, REF, ALT, variant, path)
    VALUES 
      ('chr1:1000', 'A', 'T', 'SNV', '/path/to/image1.png'),
      ('chr2:2000', 'G', 'C', 'SNV', '/path/to/image2.png'),
      ('chr3:3000', 'AT', 'A', 'DEL', '/path/to/image3.png')
  ")
  
  return(list(pool = pool, file = db_file))
}

#' Generate randomization seed
#'
#' Generates a consistent randomization seed based on user ID and timestamp.
#'
#' @param user_id Character. The user ID
#' @param timestamp Numeric. Optional timestamp (uses current time if not provided)
#' @return Integer. The generated seed
#' @export
generate_user_seed <- function(user_id, timestamp = NULL) {
  if (is.null(timestamp)) {
    timestamp <- as.numeric(Sys.time())
  }
  
  combined <- paste0(user_id, timestamp)
  seed <- strtoi(substr(digest::digest(combined, algo = "crc32"), 1, 7), base = 16)
  return(seed)
}

#' Initialize user data directory structure
#'
#' Creates the external user_data directory structure outside the package.
#'
#' @param base_path Character. Base path where user_data should be created. 
#'   Defaults to current working directory.
#' @export
init_user_data_structure <- function(base_path = getwd()) {
  # Define institute IDs
  institute_ids <- c(
    "Training_answers_not_saved",
    "CNAG",
    "DKFZ",
    "DNGC",
    "FPGMX",
    "Hartwig",
    "ISCIII",
    "KU_Leuven",
    "Latvian_BRSC",
    "MOMA",
    "SciLifeLab",
    "Universidade_de_Aveiro",
    "University_of_Helsinki",
    "University_of_Oslo",
    "University_of_Verona"
  )
  
  # Create user_data directory
  user_data_path <- file.path(base_path, "user_data")
  
  if (!dir.exists(user_data_path)) {
    dir.create(user_data_path, recursive = TRUE)
    cat("Created user_data directory at:", user_data_path, "\n")
  } else {
    cat("user_data directory already exists at:", user_data_path, "\n")
  }
  
  # Create institute subdirectories
  for (institute in institute_ids) {
    # Replace spaces with underscores in institute names
    institute_clean <- gsub(" ", "_", institute)
    institute_path <- file.path(user_data_path, institute_clean)
    
    if (!dir.exists(institute_path)) {
      dir.create(institute_path, recursive = TRUE)
      cat("Created institute directory:", institute_clean, "\n")
    }
  }
  
  # Create a README file
  readme_content <- paste(
    "# User Data Directory",
    "",
    "This directory contains user-generated data for the B1MG Variant Voting application.",
    "",
    "## Structure",
    "- Each institute has its own subdirectory",
    "- User files are stored within institute directories",
    "- Files include user info (JSON) and annotations (TSV)",
    "",
    "## Institutes",
    paste("-", institute_ids, collapse = "\n"),
    "",
    "Generated:", Sys.time(),
    sep = "\n"
  )
  
  readme_path <- file.path(user_data_path, "README.md")
  writeLines(readme_content, readme_path)
  cat("Created README.md in user_data directory\n")
  
  return(user_data_path)
}

#' Get user data directory path
#'
#' Returns the path to the external user_data directory.
#'
#' @param base_path Character. Base path to search for user_data. 
#'   Defaults to current working directory.
#' @return Character path to user_data directory
#' @export
get_user_data_path <- function(base_path = getwd()) {
  user_data_path <- file.path(base_path, "user_data")
  
  if (!dir.exists(user_data_path)) {
    warning("user_data directory not found. Run init_user_data_structure() first.")
    return(NULL)
  }
  
  return(user_data_path)
}
